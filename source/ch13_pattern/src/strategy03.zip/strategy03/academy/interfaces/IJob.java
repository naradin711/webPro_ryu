package strategy03.academy.interfaces;

public interface IJob {
   public void job ();
}
