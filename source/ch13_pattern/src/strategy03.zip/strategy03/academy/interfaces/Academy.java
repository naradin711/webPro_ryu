package strategy03.academy.interfaces;

public interface Academy {
	
}
