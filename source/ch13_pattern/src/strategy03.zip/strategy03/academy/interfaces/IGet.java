package strategy03.academy.interfaces;

public interface IGet {
   public void get();
}
