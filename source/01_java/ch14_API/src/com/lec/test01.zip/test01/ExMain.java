package com.lec.test01;

public class ExMain {
   public static void main(String[] args) {
	  Person p = new Person ("ȫ�浿", "010-9999-9999" );
	  System.out.println(p);
  }
}
